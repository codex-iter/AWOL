package mohit.codex_iter.www.awol;

public class ResultData {
    private int stynumber;
    private String fail;
    private String Semesterdesc;
    private String totalearnedcredit;
    private String holdprocessing;
    private String examperiodfrom;
    private String sgpaR;
    public static ResultData[] ld;
    public int getStynumber() {
        return stynumber;
    }

    public void setStynumber(int stynumber) {
        this.stynumber = stynumber;
    }

    public String getFail() {
        return fail;
    }

    public void setFail(String fail) {
        this.fail = fail;
    }

    public String getSemesterdesc() {
        return Semesterdesc;
    }

    public void setSemesterdesc(String semesterdesc) {
        Semesterdesc = semesterdesc;
    }

    public String getTotalearnedcredit() {
        return totalearnedcredit;
    }

    public void setTotalearnedcredit(String totalearnedcredit) {
        this.totalearnedcredit = totalearnedcredit;
    }

    public String getHoldprocessing() {
        return holdprocessing;
    }

    public void setHoldprocessing(String holdprocessing) {
        this.holdprocessing = holdprocessing;
    }

    public String getExamperiodfrom() {
        return examperiodfrom;
    }

    public void setExamperiodfrom(String examperiodfrom) {
        this.examperiodfrom = examperiodfrom;
    }

    public String getSgpaR() {
        return sgpaR;
    }

    public void setSgpaR(String sgpaR) {
        this.sgpaR = sgpaR;
    }

}
