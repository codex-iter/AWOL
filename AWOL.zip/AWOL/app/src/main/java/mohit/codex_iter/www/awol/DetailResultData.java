package mohit.codex_iter.www.awol;

public class DetailResultData {
    String subjectdesc;
    String stynumber;
    String subjectcode;
    String grade;
    String earnedcredit;

    public static DetailResultData[] ld;
    public String getSubjectdesc() {
        return subjectdesc;
    }

    public void setSubjectdesc(String subjectdesc) {
        this.subjectdesc = subjectdesc;
    }

    public String getStynumber() {
        return stynumber;
    }

    public void setStynumber(String stynumber) {
        this.stynumber = stynumber;
    }

    public String getSubjectcode() {
        return subjectcode;
    }

    public void setSubjectcode(String subjectcode) {
        this.subjectcode = subjectcode;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public String getEarnedcredit() {
        return earnedcredit;
    }

    public void setEarnedcredit(String earnedcredit) {
        this.earnedcredit = earnedcredit;
    }
}
