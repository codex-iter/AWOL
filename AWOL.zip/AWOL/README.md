# AWOL
(Attendance Without leave)
Shows current attendance

![](https://img.shields.io/badge/Built%20with-Android-blue.svg?longCache=true&style=for-the-badge&logo=android&colorB=00ddff)

[![](https://img.shields.io/badge/google-play-blue.svg?longCache=true&style=for-the-badge&logo=android&colorB=00ddff)](https://play.google.com/store/apps/details?id=mohit.codex_iter.www.awol)

## Login
<img src="./screenshots/login.jpg" width=30%>

## Attendance
<img src="./screenshots/main.jpg" width=30%>

## Menu
<img src="./screenshots/nav_bar.jpg" width=30%>

## Plan a bunk
<img src="./screenshots/bunk.jpg" width=30%>

## About Us
<img src="./screenshots/about.jpg" width=30%>

Test server credentials:

```
Username: 12345
Password: 12345
```
